// Empréstimos com cláusulas + acompanhamento dos emprestados (2026-10-12, pedido do utilizador:
// ideia 7 da quinta lista de ideias).
// Decisões de desenho confirmadas por ele:
//  - cláusulas: opção de compra, utilização mínima, quem paga o salário (percentagem já existente,
//    agora também 0%) e chamada de volta. TODAS são negociadas entre os clubes e opcionais — pode
//    emprestar-se sem opção de compra. A IA avalia-as (ver empPrecoDono/empPrecoDestino), pode
//    contrapropor e propõe-nas nas suas ofertas;
//  - acompanhamento dos meus emprestados: relatório mensal do adjunto (jogos, golos, nota,
//    evolução e conclusão), alertas de problemas (joga pouco, lesão, desperdiçado) e opinião de
//    fim de época para o plantel do ano seguinte.
//
// Dados:
//   player.emprestimo.clausulas = { opcaoCompra:{preco}|null, usoMinimo:{pct,remedio}|null, chamada:bool }
//   player.emprestimo.{inicio, rondaInicio, jogosInicio, golosInicio, notasInicio, ovrInicio,
//     usoAvisado, usoResolvido, chamadaUsada, snapshot, ultimoRelatorio, alertas}
//   session/offer .clausulas (propostas em curso); offer.counterClausulas (contraproposta minha)

const EMP_OPCAO_MULT_REF = 1.15;     // preço de referência da opção = valor de mercado x 1,15
const EMP_USO_PCTS = [30, 50, 70];
const EMP_CHAMADA_DIAS_MIN = 60;     // só se pode chamar de volta depois de 60 dias de empréstimo
const EMP_AVISO_RONDAS = 6;
const EMP_AVALIA_RONDAS = 10;
const EMP_MULTA_MESES = 3;           // multa por incumprimento da utilização mínima: 3 salários
const EMP_PARTILHAS = [0, 25, 50, 75, 100];

function empClausulasVazias(){ return { opcaoCompra: null, usoMinimo: null, chamada: false }; }
function empNormalizarClausulas(c){
  const out = empClausulasVazias();
  if(!c || typeof c !== "object") return out;
  if(c.opcaoCompra && Number(c.opcaoCompra.preco) > 0) out.opcaoCompra = { preco: Math.max(500, Math.round(Number(c.opcaoCompra.preco) / 500) * 500) };
  if(c.usoMinimo && Number(c.usoMinimo.pct) > 0) out.usoMinimo = { pct: clamp(Math.round(Number(c.usoMinimo.pct)), 10, 90), remedio: c.usoMinimo.remedio === "multa" ? "multa" : "retorno" };
  out.chamada = !!c.chamada;
  return out;
}
function empTemClausulas(c){ c = empNormalizarClausulas(c); return !!(c.opcaoCompra || c.usoMinimo || c.chamada); }
function empClausulasTexto(c){
  c = empNormalizarClausulas(c);
  const p = [];
  if(c.opcaoCompra) p.push(`opção de compra por ${fmtMoney(c.opcaoCompra.preco)}`);
  if(c.usoMinimo) p.push(`utilização mínima de ${c.usoMinimo.pct}% dos jogos (se falhar: ${c.usoMinimo.remedio === "multa" ? "multa de 3 salários" : "devolução do jogador"})`);
  if(c.chamada) p.push("chamada de volta pelo clube de origem");
  return p.length ? p.join("; ") : "sem cláusulas";
}
function empPrecoRef(player, owner){
  return Math.max(500, Math.round(playerMarketValue(player, owner) * EMP_OPCAO_MULT_REF / 500) * 500);
}

// ---- Avaliação pela IA (pontos somados ao score de aceitação) ----
// Perspetiva do clube DONO (a IA, quando eu peço um jogador emprestado): a opção de compra só
// agrada com preço de referência ou acima (fica a ganhar ao vender); a utilização mínima e a
// chamada de volta são garantias a favor do dono.
function empPrecoDono(c, player, owner){
  c = empNormalizarClausulas(c); let pts = 0;
  if(c.opcaoCompra){
    const r = c.opcaoCompra.preco / Math.max(500, playerMarketValue(player, owner));
    pts += r >= EMP_OPCAO_MULT_REF ? 5 : r >= 1 ? 1 : -Math.min(12, (1 - r) * 30);
  }
  if(c.usoMinimo) pts += 3 + c.usoMinimo.pct / 20;
  if(c.chamada) pts += 6;
  return pts;
}
// Perspetiva do clube DESTINO (a IA, quando é ela que me pede o jogador): a opção de compra a
// bom preço é um direito a seu favor; a utilização mínima e a chamada de volta são obrigações.
function empPrecoDestino(c, player, owner){
  c = empNormalizarClausulas(c); let pts = 0;
  if(c.opcaoCompra){
    const r = c.opcaoCompra.preco / Math.max(500, playerMarketValue(player, owner));
    pts += r <= 1.1 ? 4 : r <= 1.25 ? 1 : -Math.min(8, (r - 1.25) * 20);
  }
  if(c.usoMinimo) pts -= c.usoMinimo.pct / 12 + (c.usoMinimo.remedio === "multa" ? 2 : 0);
  if(c.chamada) pts -= 6;
  return pts;
}
// Contraproposta do clube dono: se a opção de compra pede pouco, sobe-a para o preço de referência.
function empContrapropostaClausulas(c, player, owner){
  c = empNormalizarClausulas(c);
  if(c.opcaoCompra){
    const r = c.opcaoCompra.preco / Math.max(500, playerMarketValue(player, owner));
    if(r < 1) c.opcaoCompra.preco = empPrecoRef(player, owner);
  }
  return c;
}
// Cláusulas que a IA põe nas suas propostas pelos meus jogadores.
function empGerarClausulasIA(player, user, ai, profile){
  const c = empClausulasVazias();
  if(Math.random() < 0.35) c.opcaoCompra = { preco: Math.max(500, Math.round(playerMarketValue(player, user) * 1.1 / 500) * 500) };
  if(profile === "jovem" && Math.random() < 0.3) c.usoMinimo = { pct: 40, remedio: Math.random() < 0.5 ? "multa" : "retorno" };
  return empNormalizarClausulas(c);
}

// ---- Editor de cláusulas (HTML partilhado pelo pedido de empréstimo e pela contraproposta) ----
function empEditorHtml(player, owner, atual){
  const c = empNormalizarClausulas(atual);
  const preco = c.opcaoCompra ? c.opcaoCompra.preco : empPrecoRef(player, owner);
  const pct = c.usoMinimo ? c.usoMinimo.pct : 50;
  const rem = c.usoMinimo ? c.usoMinimo.remedio : "retorno";
  return `<div class="emp-clausulas" style="display:grid;gap:6px;margin-top:8px;">
    <div class="helptext" style="margin:0;">Cláusulas (todas opcionais e negociadas com o clube):</div>
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;"><label><input type="checkbox" class="emp-opcao-on" ${c.opcaoCompra ? "checked" : ""}> Opção de compra</label>
      <input type="number" class="emp-opcao-preco" min="500" step="500" value="${preco}" style="width:110px;"> €</div>
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;"><label><input type="checkbox" class="emp-uso-on" ${c.usoMinimo ? "checked" : ""}> Utilização mínima</label>
      <select class="emp-uso-pct">${EMP_USO_PCTS.map(n => `<option value="${n}" ${n === pct ? "selected" : ""}>${n}% dos jogos</option>`).join("")}</select>
      <select class="emp-uso-remedio"><option value="retorno" ${rem === "retorno" ? "selected" : ""}>se falhar: devolução</option><option value="multa" ${rem === "multa" ? "selected" : ""}>se falhar: multa</option></select></div>
    <div><label><input type="checkbox" class="emp-chamada-on" ${c.chamada ? "checked" : ""}> Chamada de volta (o clube de origem pode recuperar o jogador a meio da época)</label></div>
  </div>`;
}
function empLerClausulas(container){
  const q = s => container.querySelector(s);
  if(!q(".emp-clausulas")) return empClausulasVazias();
  return empNormalizarClausulas({
    opcaoCompra: q(".emp-opcao-on") && q(".emp-opcao-on").checked ? { preco: parseInt(q(".emp-opcao-preco").value, 10) || 0 } : null,
    usoMinimo: q(".emp-uso-on") && q(".emp-uso-on").checked ? { pct: parseInt(q(".emp-uso-pct").value, 10), remedio: q(".emp-uso-remedio").value } : null,
    chamada: !!(q(".emp-chamada-on") && q(".emp-chamada-on").checked),
  });
}

// ---- Estatísticas do emprestado desde o início do empréstimo ----
function empStats(p){
  const loan = p.emprestimo; if(!loan) return null;
  const s = p.season || {};
  const jogos = Math.max(0, (s.jogos || 0) - (loan.jogosInicio || 0));
  const golos = Math.max(0, (s.golos || 0) - (loan.golosInicio || 0));
  const notas = (Array.isArray(s.notas) ? s.notas : []).slice(loan.notasInicio || 0).filter(x => typeof x === "number");
  const nota = notas.length ? notas.reduce((a, b) => a + b, 0) / notas.length : null;
  const rondas = Math.max(0, (state.currentRound || 0) - (loan.rondaInicio || 0));
  const pct = rondas > 0 ? clamp(jogos / rondas, 0, 1) : null;
  const titular = Math.max(0, (s.jogosTitular || 0) - (loan.titularInicio || 0));
  return { jogos, golos, nota, rondas, pct, titular, ovr: overall(p), ovrInicio: loan.ovrInicio != null ? loan.ovrInicio : overall(p) };
}
// ---- Jogadores cedidos (2026-10-12): continuam a aparecer no plantel do clube dono ----
// Um jogador emprestado vive fisicamente só no plantel de destino (é lá que joga, treina e conta para
// tudo), mas o clube dono continua a vê-lo na sua lista — o MESMO objeto e o mesmo ID, nunca uma cópia.
function empEmprestadosFora(ownerId){
  const out = [];
  Object.values(state.teams).filter(t=>!String(t.id||"").startsWith("selecaoNacional-")).forEach(t => (t.players || []).forEach(p => {
    const l = p.emprestimo;
    if(l && l.ownerId === ownerId && l.destinationId !== ownerId) out.push({ p, dest: t });
  }));
  return out;
}
// Jogador do utilizador (equipa A ou B) emprestado a um clube de fora.
function empCedidoPeloUtilizador(p){
  const l = p && p.emprestimo, my = state.teams[state.userTeamId];
  if(!l || !my) return false;
  const ids = [my.id, my.equipaBId].filter(Boolean);
  return ids.includes(l.ownerId) && !ids.includes(l.destinationId);
}
// Passa um jogador cedido do plantel A para o B (ou vice-versa): só muda a equipa a que regressa.
function empMudarEquipaOrigem(playerId, targetId){
  const pair = internalTransferPairForUser();
  if(!pair || ![pair.a.id, pair.b.id].includes(targetId)) return { ok: false, reason: "Movimento interno inválido." };
  let found = null;
  Object.values(state.teams).filter(t=>!String(t.id||"").startsWith("selecaoNacional-")).forEach(t => (t.players || []).forEach(p => { if(p.id === playerId && p.emprestimo) found = p; }));
  if(!found || !empCedidoPeloUtilizador(found)) return { ok: false, reason: "Jogador não está emprestado por ti." };
  if(found.emprestimo.ownerId === targetId) return { ok: false, reason: "Já está nessa equipa." };
  found.emprestimo.ownerId = targetId;
  return { ok: true, player: found };
}
function empEmprestadosDoUtilizador(){
  const my = state.teams[state.userTeamId]; if(!my) return { fora: [], dentro: [] };
  const ids = new Set([my.id, my.equipaBId].filter(Boolean));
  const fora = [], dentro = [];
  Object.values(state.teams).filter(t=>!String(t.id||"").startsWith("selecaoNacional-")).forEach(t => (t.players || []).forEach(p => {
    const l = p.emprestimo; if(!l) return;
    if(ids.has(l.ownerId) && !ids.has(l.destinationId)) fora.push({ p, dest: t, owner: state.teams[l.ownerId] });
    else if(ids.has(l.destinationId) && !ids.has(l.ownerId)) dentro.push({ p, dest: t, owner: state.teams[l.ownerId] });
  }));
  return { fora, dentro };
}

// ---- Regresso, retorno forçado e compra ----
// canReleasePlayerFromTeam recusa sempre jogadores emprestados; aqui só interessa o mínimo estrutural.
function empDestinoPodePerder(dest, p){
  const l = p.emprestimo; p.emprestimo = null;
  try { return canReleasePlayerFromTeam(dest, p); } finally { p.emprestimo = l; }
}
function empMoverParaDono(p, dest, owner, motivo, opts){
  dest.players = dest.players.filter(x => x.id !== p.id);
  owner.players.push(p);
  dest.marketNeedDirty = true;
  const loan = p.emprestimo;
  p.emprestimo = null; p.titular = false;
  const season = movementEntrySeason();
  recordClubMovement(season, owner, "entrada", motivo, 0, p, dest);
  recordClubMovement(season, dest, "saida", motivo, 0, p, owner);
  return loan;
}
function empConcluirCompra(p, owner, dest, preco, origem){
  initClubFinance(owner); initClubFinance(dest);
  addFinanceMovement(dest, "despesa", "Transferências", `Opção de compra de ${p.name}`, preco, state.currentDate);
  addFinanceMovement(owner, "receita", "Transferências", `Venda de ${p.name} (opção de compra)`, preco, state.currentDate);
  dest.financeiro.orcamentoTransferencias = Math.max(0, (dest.financeiro.orcamentoTransferencias || 0) - preco);
  p.emprestimo = null; p.titular = false;
  registerPlayerEntry(p, dest, "transferencia", preco, owner);
  state.transferHistory.unshift({ player: p.name, from: owner.name, to: dest.name, value: preco });
  const envolve = isUserControlledTeam(owner) || isUserControlledTeam(dest);
  pushNews(state.currentDate, `${teamLinkHtml(dest.id)} ${origem === "utilizador" ? "exerceu" : "exerceu"} a opção de compra de ${playerLinkHtml(dest.id, p)} por ${fmtMoney(preco)}. O jogador fica definitivamente no clube.`, "mercado", `Opção de compra exercida: ${p.name}`, { autoAdvanceStop: envolve, teamId: dest.id });
}
// A IA decide, no fim do empréstimo, se exerce a opção de compra.
function empIAExerceOpcao(p, dest, owner, loan){
  const preco = loan.clausulas.opcaoCompra.preco;
  const st = empStats(p);
  const ref = (dest.players || []).filter(x => x.pos === p.pos && (p.pos === "GR" || x.linha === p.linha) && x.id !== p.id).sort((a, b) => overall(b) - overall(a));
  const nTit = p.pos === "GR" ? 1 : (p.linha === "Avancado" ? 2 : 3);
  const refOvr = ref[nTit - 1] ? overall(ref[nTit - 1]) : 0;
  const servePeloNivel = overall(p) >= refOvr - 0.5 || (p.age <= 23 && p.potential - overall(p) >= 3);
  const jogou = st && st.pct != null ? st.pct >= 0.4 : true;
  if(!servePeloNivel || !jogou) return false;
  const salario = (p.contrato && p.contrato.salarioMensal) || 0;
  const total = aiTotalRecruitmentCost(p, dest, "compras", preco, salario);
  if(!aiRecruitmentFinanciallySafe(dest, total, preco, salario)) return false;
  if(Math.random() > 0.85) return false;
  aiRegisterRecruitment(dest, p, "compras", total);
  return true;
}
// Opinião do adjunto sobre um emprestado que regressa ao utilizador.
function empOpiniaoRegresso(owner, p, st){
  const grupo = expGrupoDoJogador(owner, p).filter(x => x.id !== p.id);
  const nTit = p.pos === "GR" ? 1 : (p.linha === "Avancado" ? 2 : 3);
  const ref = grupo[nTit - 1] || grupo[grupo.length - 1] || null;
  const refOvr = ref ? overall(ref) : 0;
  const gap = ref ? overall(p) - refOvr : 99;
  const evol = st.ovr - st.ovrInicio;
  let id, texto;
  if(gap >= 0.5){ id = "integrar"; texto = `Já tem nível para o teu onze${ref ? ` (acima de ${ref.name}, OVR ${refOvr})` : ""}. Integra-o no plantel principal.`; }
  else if(gap >= -1){ id = "rotacao"; texto = `Fica ao nível da rotação${ref ? ` (perto de ${ref.name}, OVR ${refOvr})` : ""}. Vale a pena mantê-lo como opção.`; }
  else if(p.age <= 23 && p.potential - overall(p) >= 3){ id = "emprestar"; texto = "Ainda não tem nível para o onze, mas tem margem de progressão: volta a emprestá-lo para continuar a jogar."; }
  else { id = "vender"; texto = "Não tem lugar no teu futuro próximo e a margem de progressão é curta: o melhor é vendê-lo ou libertá-lo."; }
  return { id, texto, evol };
}
function empFimDeEmprestimo(dest, owner, p, loan){
  const c = empNormalizarClausulas(loan.clausulas);
  const donoUser = isUserControlledTeam(owner), destUser = isUserControlledTeam(dest);
  if(c.opcaoCompra){
    if(destUser){
      pushNews(state.currentDate, `A opção de compra de ${playerLinkHtml(dest.id, p)} (${fmtMoney(c.opcaoCompra.preco)}) caducou com o fim do empréstimo — o jogador regressa a ${teamLinkHtml(owner.id)}.`, "proposta", `Opção de compra caducada: ${p.name}`, { autoAdvanceStop: true, teamId: owner.id });
    } else if(empIAExerceOpcao(p, dest, owner, { ...loan, clausulas: c })){
      empConcluirCompra(p, owner, dest, c.opcaoCompra.preco, "ia");
      return true;
    }
  }
  if(donoUser){
    const st = empStats(p);
    if(st){
      const op = empOpiniaoRegresso(owner, p, st);
      const notaTxt = st.nota != null ? `, nota média ${st.nota.toFixed(1)}` : "";
      const evolTxt = op.evol > 0 ? ` O OVR subiu ${op.evol} no empréstimo.` : op.evol < 0 ? ` O OVR desceu ${-op.evol} no empréstimo.` : "";
      pushNews(state.currentDate, `Opinião do adjunto sobre ${playerLinkHtml(owner.id, p)}, que regressa do empréstimo ao ${escapeHtml(dest.name)}: ${st.jogos} jogos, ${st.golos} golos${notaTxt}.${evolTxt} <b>${{ integrar: "Integrar no plantel", rotacao: "Manter na rotação", emprestar: "Voltar a emprestar", vender: "Vender ou libertar" }[op.id]}</b>: ${op.texto}`, "scouting", `Emprestado de volta: ${p.name}`, { autoAdvanceStop: true, teamId: owner.id });
    }
  }
  return false;
}

// ---- Ações do utilizador ----
function empExercerOpcao(playerId){
  const dest = state.teams[state.userTeamId];
  const p = (dest.players || []).find(x => x.id === playerId);
  if(!p || !p.emprestimo) return { ok: false, reason: "Este jogador já não está emprestado." };
  const loan = p.emprestimo, c = empNormalizarClausulas(loan.clausulas);
  if(loan.destinationId !== dest.id || !c.opcaoCompra) return { ok: false, reason: "Este empréstimo não tem opção de compra." };
  const owner = state.teams[loan.ownerId];
  initClubFinance(dest);
  const preco = c.opcaoCompra.preco;
  if((dest.financeiro.orcamentoTransferencias || 0) < preco) return { ok: false, reason: `Orçamento de transferências insuficiente (${fmtMoney(dest.financeiro.orcamentoTransferencias || 0)}).` };
  const bloqueio = crisisSpendingBlock(dest, "contratacao", (p.contrato && p.contrato.salarioMensal) || 0, p);
  if(bloqueio) return { ok: false, reason: bloqueio };
  empConcluirCompra(p, owner, dest, preco, "utilizador");
  return { ok: true, preco };
}
function empChamarDeVolta(playerId){
  const owner = state.teams[state.userTeamId];
  let found = null;
  Object.values(state.teams).filter(t=>!String(t.id||"").startsWith("selecaoNacional-")).forEach(t => { const p = (t.players || []).find(x => x.id === playerId && x.emprestimo); if(p) found = { p, dest: t }; });
  if(!found) return { ok: false, reason: "Este jogador já não está emprestado." };
  const { p, dest } = found, loan = p.emprestimo, c = empNormalizarClausulas(loan.clausulas);
  const ids = new Set([owner.id, owner.equipaBId].filter(Boolean));
  if(!ids.has(loan.ownerId) || !c.chamada) return { ok: false, reason: "Este empréstimo não tem cláusula de chamada de volta." };
  if(loan.chamadaUsada) return { ok: false, reason: "A cláusula de chamada de volta já foi usada." };
  const dias = Math.round((new Date(isoDate(state.currentDate) + "T00:00:00Z") - new Date((loan.inicio || isoDate(state.currentDate)) + "T00:00:00Z")) / 86400000);
  if(dias < EMP_CHAMADA_DIAS_MIN) return { ok: false, reason: `Só podes chamar o jogador de volta depois de ${EMP_CHAMADA_DIAS_MIN} dias de empréstimo (faltam ${EMP_CHAMADA_DIAS_MIN - dias}).` };
  const chk = empDestinoPodePerder(dest, p);
  if(!chk.ok) return { ok: false, reason: `${dest.name} ficaria sem jogadores suficientes: ${chk.reason}` };
  const donoReal = state.teams[loan.ownerId];
  empMoverParaDono(p, dest, donoReal, "fim-emprestimo");
  pushNews(state.currentDate, `${teamLinkHtml(donoReal.id)} usou a cláusula de chamada de volta e recuperou ${playerLinkHtml(donoReal.id, p)}, que estava emprestado a ${teamLinkHtml(dest.id)}.`, "mercado", `Chamada de volta: ${p.name}`, { autoAdvanceStop: true, teamId: donoReal.id });
  return { ok: true };
}
// A IA (dona) chama de volta um jogador meu emprestado quando tem uma crise no seu plantel.
function empIAChamaDeVolta(p, dest, owner, loan){
  const c = empNormalizarClausulas(loan.clausulas);
  if(!c.chamada || loan.chamadaUsada) return false;
  const dias = Math.round((new Date(isoDate(state.currentDate) + "T00:00:00Z") - new Date((loan.inicio || isoDate(state.currentDate)) + "T00:00:00Z")) / 86400000);
  if(dias < EMP_CHAMADA_DIAS_MIN) return false;
  const disponiveis = (owner.players || []).filter(x => x.pos === p.pos && !x.emprestimo && playerAvailableForMatch(x));
  const minimo = p.pos === "GR" ? 2 : 6;
  if(disponiveis.length >= minimo) return false;
  const chk = empDestinoPodePerder(dest, p);
  if(!chk.ok) return false;
  empMoverParaDono(p, dest, owner, "fim-emprestimo");
  pushNews(state.currentDate, `${teamLinkHtml(owner.id)} usou a cláusula de chamada de volta e recuperou ${playerLinkHtml(owner.id, p)}, por falta de opções no plantel.`, "mercado", `Chamada de volta: ${p.name}`, { autoAdvanceStop: true, teamId: owner.id });
  return true;
}

// ---- Diário: utilização mínima, alertas, snapshot e relatório mensal ----
function empDiasDesde(iso){ return Math.round((new Date(isoDate(state.currentDate) + "T00:00:00Z") - new Date(iso + "T00:00:00Z")) / 86400000); }
function empConclusaoMensal(p, st, loan, donoNoUser){
  const c = empNormalizarClausulas(loan.clausulas);
  const evol = st.ovr - st.ovrInicio;
  if(st.pct != null && st.rondas >= 5 && st.pct < 0.35) return { id: "poucojogo", texto: c.chamada ? "Joga pouco. Considera chamar o jogador de volta (tens a cláusula) ou falar com o clube." : "Joga pouco. Fala com o clube sobre a utilização — não tens cláusula de chamada." };
  if(st.pct != null && st.pct >= 0.6 && (st.nota == null || st.nota >= 6.5)) return { id: "ficar", texto: evol > 0 ? "Está a render e a evoluir. Deixa-o terminar o empréstimo." : "Está a render. Deixa-o terminar o empréstimo." };
  if(evol >= 1) return { id: "ficar", texto: "Está a evoluir. Deixa-o continuar." };
  return { id: "acompanhar", texto: "Sem sinais claros para decidir. Continua a acompanhar." };
}
function processarEmprestimosDiario(){
  const my = state.teams[state.userTeamId]; if(!my) return;
  const hoje = isoDate(state.currentDate);
  Object.values(state.teams).filter(t=>!String(t.id||"").startsWith("selecaoNacional-")).forEach(t => (t.players || []).slice().forEach(p => {
    const loan = p.emprestimo; if(!loan) return;
    const c = empNormalizarClausulas(loan.clausulas);
    const owner = state.teams[loan.ownerId], dest = t;
    if(!owner) return;
    const envolve = isUserControlledTeam(owner) || isUserControlledTeam(dest);
    if(!envolve) return;
    const userDono = isUserControlledTeam(owner);
    const st = empStats(p);
    if(userDono && st) loan.snapshot = { data: hoje, jogos: st.jogos, golos: st.golos, nota: st.nota, ovr: st.ovr };
    // Chamada de volta pela IA (jogador meu emprestado a mim por uma IA)
    if(!userDono && c.chamada && empIAChamaDeVolta(p, dest, owner, loan)) return;
    // Utilização mínima
    if(c.usoMinimo && !loan.usoResolvido && st && st.pct != null){
      const necessario = c.usoMinimo.pct / 100;
      if(st.rondas >= EMP_AVISO_RONDAS && !loan.usoAvisado && st.pct < necessario){
        loan.usoAvisado = true;
        pushNews(state.currentDate, `Atenção: ${playerLinkHtml(dest.id, p)} só jogou ${Math.round(st.pct * 100)}% dos jogos desde o empréstimo e a cláusula de utilização mínima exige ${c.usoMinimo.pct}%. ${userDono ? `${escapeHtml(dest.name)} arrisca-se a ${c.usoMinimo.remedio === "multa" ? "pagar uma multa" : "ter de devolver o jogador"}.` : `Se não o utilizares mais, terás de ${c.usoMinimo.remedio === "multa" ? "pagar uma multa" : "devolver o jogador"}.`}`, "scouting", `Utilização mínima em risco: ${p.name}`, { autoAdvanceStop: true, teamId: userDono ? dest.id : owner.id });
      }
      if(st.rondas >= EMP_AVALIA_RONDAS){
        loan.usoResolvido = true;
        if(st.pct < necessario){
          if(c.usoMinimo.remedio === "multa" || !empDestinoPodePerder(dest, p).ok){
            const multa = Math.round(((p.contrato && p.contrato.salarioMensal) || 0) * EMP_MULTA_MESES / 50) * 50;
            if(multa > 0){
              addFinanceMovement(dest, "despesa", "Outras", `Multa por incumprimento da utilização mínima de ${p.name}`, multa, state.currentDate);
              addFinanceMovement(owner, "receita", "Outras", `Multa recebida por incumprimento da utilização mínima de ${p.name}`, multa, state.currentDate);
            }
            pushNews(state.currentDate, `${teamLinkHtml(dest.id)} não cumpriu a utilização mínima de ${playerLinkHtml(dest.id, p)} (${Math.round(st.pct * 100)}% dos jogos, exigidos ${c.usoMinimo.pct}%) e paga uma multa de ${fmtMoney(multa)} a ${teamLinkHtml(owner.id)}.`, "proposta", `Multa por utilização mínima: ${p.name}`, { autoAdvanceStop: true, teamId: dest.id });
          } else {
            empMoverParaDono(p, dest, owner, "fim-emprestimo");
            pushNews(state.currentDate, `${teamLinkHtml(dest.id)} não cumpriu a utilização mínima de ${playerLinkHtml(owner.id, p)} (${Math.round(st.pct * 100)}% dos jogos, exigidos ${c.usoMinimo.pct}%) e devolve o jogador a ${teamLinkHtml(owner.id)}.`, "proposta", `Jogador devolvido: ${p.name}`, { autoAdvanceStop: true, teamId: dest.id });
          }
          return;
        }
      }
    }
    // Alertas de problemas (só para os meus emprestados)
    if(userDono && st){
      loan.alertas = loan.alertas || {};
      const al = loan.alertas;
      if(st.rondas >= 5 && st.pct != null && st.pct < 0.35 && (!al.poucoJogo || empDiasDesde(al.poucoJogo) >= 45)){
        al.poucoJogo = hoje;
        const grupo = (dest.players || []).filter(x => x.pos === p.pos && (p.pos === "GR" || x.linha === p.linha) && x.id !== p.id).sort((a, b) => overall(b) - overall(a));
        const nTit = p.pos === "GR" ? 1 : (p.linha === "Avancado" ? 2 : 3);
        const refOvr = grupo[nTit - 1] ? overall(grupo[nTit - 1]) : 0;
        const desperdicado = overall(p) >= refOvr + 0.5;
        pushNews(state.currentDate, `Alerta do adjunto: ${playerLinkHtml(dest.id, p)} só jogou ${Math.round(st.pct * 100)}% dos jogos de ${escapeHtml(dest.name)} desde o empréstimo.${desperdicado ? " Tem nível acima dos titulares da posição — o clube está a desperdiçá-lo." : ""} ${c.chamada && empDiasDesde(loan.inicio || hoje) >= EMP_CHAMADA_DIAS_MIN ? "Podes chamá-lo de volta (Mercado, secção Empréstimos)." : c.chamada ? "A chamada de volta só fica disponível passados 60 dias." : "Não tens cláusula de chamada de volta — fala com o clube."}`, "scouting", `Emprestado joga pouco: ${p.name}`, { autoAdvanceStop: true, teamId: dest.id });
      }
      if((p.diasLesao || 0) >= 14 && !al.lesao){
        al.lesao = hoje;
        pushNews(state.currentDate, `Alerta do adjunto: ${playerLinkHtml(dest.id, p)} está lesionado em ${escapeHtml(dest.name)} e deve falhar cerca de ${p.diasLesao} dias.`, "scouting", `Emprestado lesionado: ${p.name}`, { autoAdvanceStop: true, teamId: dest.id });
      }
      if((p.diasLesao || 0) <= 0) al.lesao = null;
    }
  }));
  // Relatório mensal (1.º dia de cada mês) dos jogadores que emprestei
  if(new Date(state.currentDate).getDate() === 1){
    const chave = hoje.slice(0, 7);
    if(my.empRelatorioMes !== chave){
      my.empRelatorioMes = chave;
      const { fora } = empEmprestadosDoUtilizador();
      if(fora.length){
        const linhas = fora.map(({ p, dest }) => {
          const st = empStats(p); if(!st) return null;
          const concl = empConclusaoMensal(p, st, p.emprestimo, true);
          p.emprestimo.ultimoRelatorio = { data: hoje, jogos: st.jogos, golos: st.golos, nota: st.nota, ovr: st.ovr, ovrInicio: st.ovrInicio, conclusao: concl };
          const notaTxt = st.nota != null ? `, nota média ${st.nota.toFixed(1)}` : "";
          const evol = st.ovr - st.ovrInicio;
          return [`${playerLinkHtml(dest.id, p)}<br><span style="color:#8a9097;font-size:12px;">${escapeHtml(dest.name)}</span>`, `${st.jogos} jogos${st.pct != null ? ` (${Math.round(st.pct * 100)}% dos jogos do clube)` : ""}, ${st.golos} golos${notaTxt}; OVR ${st.ovr}${evol ? ` (${evol > 0 ? "+" : ""}${evol} desde o início)` : ""}. <b>${concl.texto}</b>`];
        }).filter(Boolean);
        pushNews(state.currentDate, repDoc({
          teamId: my.id, org: "Departamento técnico", titulo: "Relatório mensal dos emprestados",
          sub: `${fora.length} jogador${fora.length > 1 ? "es" : ""} emprestado${fora.length > 1 ? "s" : ""}`,
          secoes: [{ icone: "🔁", titulo: "Rendimento por jogador", cheia: true, linhas }],
          rodape: "Empréstimos · treinador adjunto",
        }), "scouting", "Relatório mensal dos emprestados", { autoAdvanceStop: false, teamId: my.id });
      }
    }
  }
}

// ---- Interface ----
function empJanelaModal(titulo, corpoHtml){
  const m = balnearioModalEl();
  m.querySelector("#balnearioModalTitle").textContent = titulo;
  m.querySelector("#balnearioModalBody").innerHTML = corpoHtml;
  m.classList.remove("hidden");
  return m;
}
function renderEmprestimosSection(team){
  const panelBody = document.querySelector("#viewMercado .panel-body");
  if(!panelBody) return;
  let box = document.getElementById("emprestimosBox");
  if(!box){
    box = document.createElement("div"); box.id = "emprestimosBox";
    const ref = document.getElementById("aiOffersBox");
    panelBody.insertBefore(box, ref ? ref.nextSibling : panelBody.firstChild);
  }
  const { fora, dentro } = empEmprestadosDoUtilizador();
  if(!fora.length && !dentro.length){ box.innerHTML = ""; return; }
  const linha = ({ p, dest, owner }, dentroDeMim) => {
    const l = p.emprestimo, c = empNormalizarClausulas(l.clausulas), st = empStats(p);
    const stTxt = st ? `${st.jogos} jogos · ${st.golos} golos${st.nota != null ? ` · nota ${st.nota.toFixed(1)}` : ""} · OVR ${st.ovr}${st.ovr !== st.ovrInicio ? ` (${st.ovr > st.ovrInicio ? "+" : ""}${st.ovr - st.ovrInicio})` : ""}` : "";
    const rel = !dentroDeMim && l.ultimoRelatorio ? ` <button class="btn btn-ghost emp-rel" data-player="${escapeHtml(p.id)}">Último relatório</button>` : "";
    const btns = [];
    if(dentroDeMim && c.opcaoCompra) btns.push(`<button class="btn btn-primary emp-exercer" data-player="${escapeHtml(p.id)}">Exercer opção (${fmtMoney(c.opcaoCompra.preco)})</button>`);
    if(!dentroDeMim && c.chamada && !l.chamadaUsada) btns.push(`<button class="btn btn-ghost emp-chamar" data-player="${escapeHtml(p.id)}">Chamar de volta</button>`);
    const outro = dentroDeMim ? owner : dest;
    return `<div class="fixture-row" style="grid-template-columns:2fr 3fr auto;align-items:center;"><div><b>${playerNameHtml(p)}</b><div class="market-meta">${dentroDeMim ? "Emprestado por" : "Emprestado a"} ${escapeHtml(outro ? outro.name : "—")} · ${l.salaryShare}% do salário no destino</div></div>
      <div class="helptext" style="margin:0;">${stTxt}<br>Cláusulas: ${empClausulasTexto(c)}</div><div>${btns.join(" ")}${rel}</div></div>`;
  };
  box.innerHTML = `<div class="eyebrow" style="margin:16px 0 8px;">Empréstimos (${fora.length} cedidos · ${dentro.length} recebidos)</div>
    ${fora.map(x => linha(x, false)).join("")}${dentro.map(x => linha(x, true)).join("")}`;
}

document.addEventListener("click", (e) => {
  const t = e.target; if(!t || !t.closest) return;
  const ex = t.closest(".emp-exercer");
  if(ex){
    const r = empExercerOpcao(ex.getAttribute("data-player"));
    showTransientNotice(r.ok ? `Opção de compra exercida por ${fmtMoney(r.preco)}.` : r.reason);
    if(typeof renderTransferMarket === "function") renderTransferMarket();
    if(typeof renderRoster === "function") renderRoster();
    return;
  }
  const ch = t.closest(".emp-chamar");
  if(ch){
    const r = empChamarDeVolta(ch.getAttribute("data-player"));
    showTransientNotice(r.ok ? "Jogador chamado de volta ao clube." : r.reason);
    if(typeof renderTransferMarket === "function") renderTransferMarket();
    if(typeof renderRoster === "function") renderRoster();
    return;
  }
  const rel = t.closest(".emp-rel");
  if(rel){
    const { fora } = empEmprestadosDoUtilizador();
    const x = fora.find(y => y.p.id === rel.getAttribute("data-player"));
    const r = x && x.p.emprestimo.ultimoRelatorio;
    if(!r){ showTransientNotice("Ainda não há relatório deste jogador."); return; }
    empJanelaModal(`Relatório — ${x.p.name}`, `<p>Relatório de ${escapeHtml(r.data)}: ${r.jogos} jogos, ${r.golos} golos${r.nota != null ? `, nota média ${r.nota.toFixed(1)}` : ""}; OVR ${r.ovr} (início: ${r.ovrInicio}).</p><p><b>${escapeHtml(r.conclusao.texto)}</b></p>`);
    return;
  }
  const cp = t.closest(".emp-contrapropor");
  if(cp) empAbrirContraproposta(cp.getAttribute("data-offer"));
  const env = t.closest("#empContraEnviar");
  if(env) empEnviarContraproposta();
});

// Contraproposta a uma proposta de empréstimo da IA (substitui o antigo prompt()).
let empOfertaEmContraproposta = null;
function empAbrirContraproposta(offerId){
  const o = (state.aiOffers || []).find(x => x.id === offerId);
  const my = state.teams[state.userTeamId];
  const p = o && my.players.find(x => x.id === o.playerId);
  if(!o || !p || o.type !== "emprestimo") return;
  empOfertaEmContraproposta = offerId;
  const buyer = state.teams[o.fromTeamId];
  const roleOpts = ["Titular", "Rotacao", "Desenvolvimento"].map(r => `<option value="${r}" ${r === o.papel ? "selected" : ""}>${ROLE_LABELS[r] || r}</option>`).join("");
  empJanelaModal(`Contraproposta — ${p.name}`, `<p class="helptext">Proposta de ${escapeHtml(buyer.name)}: ${o.salaryShare}% do salário · ${ROLE_LABELS[o.papel] || o.papel} · ${empClausulasTexto(o.clausulas)}.</p>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
      <label style="font-size:12px;">Salário suportado pelo destino<select id="empContraShare">${EMP_PARTILHAS.map(n => `<option ${n === o.salaryShare ? "selected" : ""}>${n}</option>`).join("")}</select></label>
      <label style="font-size:12px;">Papel<select id="empContraRole">${roleOpts}</select></label>
    </div>
    <div id="empContraEditor">${empEditorHtml(p, my, o.clausulas)}</div>
    <div style="margin-top:12px;"><button class="btn btn-primary" id="empContraEnviar">Enviar contraproposta</button></div>`);
}
function empEnviarContraproposta(){
  const id = empOfertaEmContraproposta; if(!id) return;
  const m = balnearioModalEl();
  const share = parseInt(m.querySelector("#empContraShare").value, 10);
  const papel = m.querySelector("#empContraRole").value;
  const clausulas = empLerClausulas(m.querySelector("#empContraEditor"));
  const r = respondToAiOffer(id, "contrapropor", { salaryShare: share, papel, clausulas });
  m.classList.add("hidden"); empOfertaEmContraproposta = null;
  if(r && r.ok === false && r.reason) showTransientNotice(r.reason);
  if(typeof renderTransferMarket === "function") renderTransferMarket();
}
