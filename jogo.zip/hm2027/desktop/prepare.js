// Prepara a pasta dist/ com SÓ os ficheiros que o jogo usa em execução (o Tauri embute esta pasta).
// Corre sem dependências: node desktop/prepare.js  (o Tauri chama-o antes de compilar).
const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");
const dist = path.join(root, "dist");

fs.rmSync(dist, { recursive: true, force: true });
fs.mkdirSync(dist, { recursive: true });

const itens = [
  "index.html",
  "css",
  "fonts",
  "img",
  "database",
  path.join("js", "app.js"),
];
for (const rel of itens) {
  const origem = path.join(root, rel);
  if (!fs.existsSync(origem)) { console.error("Falta: " + rel); process.exit(1); }
  const destino = path.join(dist, rel);
  fs.mkdirSync(path.dirname(destino), { recursive: true });
  fs.cpSync(origem, destino, { recursive: true });
}
console.log("dist/ pronto.");
